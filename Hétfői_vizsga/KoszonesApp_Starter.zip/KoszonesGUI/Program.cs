﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities;
using KoszonesClassLibrary;

namespace KoszonesGUI
{
    class Program
    {
        private static Graf<Ember> talakozoraErkezettEmberekGrafja = new Graf<Ember>();
        private static GrafEl<Ember>[] mostLetrejottGrafElek = new GrafEl<Ember>[] { };
        public static void Main(string[] args)
        {
            #region Társaság
            #endregion
            #region Érkezések
            #endregion
        }
        private static void PrintKoszonesekErkezeskor(Ember megerkezett, GrafEl<Ember>[] grafElek)
        {
        }
    }
}
